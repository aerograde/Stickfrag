// Standalone client: never join a live room. This runs before play-redirect.js,
// so the URL it rewrites is the one the game reads at module start.
(() => {
  const q = new URLSearchParams(location.search);
  q.set('offline', '');
  q.delete('room');
  q.delete('code');
  q.delete('region');
  q.delete('review');
  q.delete('overwatch');
  q.delete('case');
  q.delete('studio');
  q.delete('replay');
  q.delete('clip');
  if (!/^[A-Za-z0-9_]{3,16}$/.test((q.get('name') || '').trim())) q.set('name', 'player');
  const next = location.pathname + '?' + q.toString();
  if (next !== location.pathname + location.search) history.replaceState(null, '', next);
})();
